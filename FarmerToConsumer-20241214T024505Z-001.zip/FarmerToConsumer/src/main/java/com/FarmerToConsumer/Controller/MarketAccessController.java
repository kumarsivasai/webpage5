package com.FarmerToConsumer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.FarmerToConsumer.Model.Commodity;
import com.FarmerToConsumer.Model.CommodityRecord;
import com.FarmerToConsumer.Model.CommodityResponse;
import com.FarmerToConsumer.Model.LoginRequest;
import com.FarmerToConsumer.Model.LoginResponse;
import com.FarmerToConsumer.Model.User;
import com.FarmerToConsumer.Service.MarketAccessService;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*") // Allow all origins
public class MarketAccessController {

    @Autowired
    private MarketAccessService service;

    @PostMapping("/register")
    public User registerUser(@RequestBody User user) {
        return service.registerUser(user);
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponse> login(@RequestBody LoginRequest loginRequest) {
        System.out.println("Email : " + loginRequest.getEmail());
        LoginResponse response = service.loginUser(loginRequest.getEmail(), loginRequest.getPassword());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping("/commodities")
    public Commodity addCommodity(@RequestBody Commodity commodity) {
        return service.addCommodity(commodity);
    }

    @GetMapping("/userCommodities")
    public List<Commodity> getUserCommodities(@RequestParam Long id) {
        return service.getUserCommodities(id);
    }

    @GetMapping("/fetchAllUserCommodities")
    public List<Commodity> fetchAllUserCommodityData(@RequestParam String state) {
        return service.fetchCommodityData(state);
    }

    @GetMapping("/commodities")
    public List<CommodityRecord> getCommodityRecords(@RequestParam String state) {
        return service.fetchCommodityRecords(state);
    }
}