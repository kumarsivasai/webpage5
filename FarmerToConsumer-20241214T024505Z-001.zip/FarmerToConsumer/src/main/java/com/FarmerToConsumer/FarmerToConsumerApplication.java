package com.FarmerToConsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FarmerToConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FarmerToConsumerApplication.class, args);
	}

}
