package com.FarmerToConsumer.Repo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.FarmerToConsumer.Model.Commodity;
import com.FarmerToConsumer.Model.CommodityResponse;

public interface CommodityRepository extends JpaRepository<Commodity, Long> {

	@Query("SELECT c FROM Commodity c WHERE c.farmer.id = :farmerId")
	List<Commodity> findByFarmerId(@Param("farmerId") Long farmerId);

	@Query("SELECT c  FROM Commodity c WHERE location = :location")
	List<Commodity> findCommoditiesByLocation(@Param("location") String location);
}