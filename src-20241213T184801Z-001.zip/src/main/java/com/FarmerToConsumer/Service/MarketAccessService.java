package com.FarmerToConsumer.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.FarmerToConsumer.Model.Commodity;
import com.FarmerToConsumer.Model.CommodityRecord;
import com.FarmerToConsumer.Model.CommodityResponse;
import com.FarmerToConsumer.Model.LoginResponse;
import com.FarmerToConsumer.Model.User;
import com.FarmerToConsumer.Repo.CommodityRepository;
import com.FarmerToConsumer.Repo.UserRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.classic.Logger;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class MarketAccessService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CommodityRepository commodityRepository;

    private final String apiUrl = "https://api.data.gov.in/resource/9ef84268-d588-465a-a308-a864a43d0070";
    private final String apiKey = "579b464db66ec23bdd000001cdd3946e44ce4aad7209ff7b23ac571b";

    public User registerUser(User user) {
        return userRepository.save(user);
    }

    public Commodity addCommodity(Commodity commodity) {
        return commodityRepository.save(commodity);
    }

    public List<Commodity> getUserCommodities(Long id) {
        return commodityRepository.findByFarmerId(id);
    }

    public List<Commodity> fetchCommodityData(String state) {
        // Retrieve commodities from the repository based on location
        List<Commodity> commodities = commodityRepository.findCommoditiesByLocation(state);

        

        return commodities;
    }
    
    public List<CommodityRecord> fetchCommodityRecords(String state) {
        RestTemplate restTemplate = new RestTemplate();
        String url = String.format("%s?api-key=%s&format=json&filters[state.keyword]=%s", apiUrl, apiKey, state);
        String response = restTemplate.getForObject(url, String.class);

        try {
            ObjectMapper mapper = new ObjectMapper();
            Map<String, Object> jsonMap = mapper.readValue(response, new TypeReference<Map<String, Object>>() {});
            return mapper.convertValue(jsonMap.get("records"), new TypeReference<List<CommodityRecord>>() {});
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to parse commodity data");
        }
    }

    public LoginResponse loginUser(String username, String password) {
    	System.out.println("UserName : "+ username);
        Optional<User> optionalUser = userRepository.findByEmail(username);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            // Assuming password is stored in plain text, but you should ideally hash it and compare
            if (user.getPassword().equals(password)) {
                String userId = user.getId().toString();
                String role = user.getRole().toString();
                return new LoginResponse("Login successful", userId,role);
            } else {
                return new LoginResponse("Invalid password", null, null);
            }
        } else {
            return new LoginResponse("User not found", null,null);
        }
    }
    
    
}
