package com.FarmerToConsumer.Model;

public class CommodityResponse {
 private String item;
 private Double price;
 private String location;

 public CommodityResponse(String item, Double price, String location) {
     this.item = item;
     this.price = price;
     this.location = location;
 }

 // Getters and Setters

 public String getItem() {
     return item;
 }

 public void setItem(String item) {
     this.item = item;
 }

 public Double getPrice() {
     return price;
 }

 public void setPrice(Double price) {
     this.price = price;
 }

 public String getLocation() {
     return location;
 }

 public void setLocation(String location) {
     this.location = location;
 }

 
}