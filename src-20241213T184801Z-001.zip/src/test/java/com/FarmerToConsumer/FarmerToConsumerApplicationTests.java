package com.FarmerToConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FarmerToConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
